package com.facebook.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

/**
 * Created by Arghya on 19-04-2016.
 */
public class BasePage {

    WebDriver driver;
    BasePage(WebDriver driver){
        this.driver=driver;
    }
    public void loadPage(){

    }

    public void clickElement(){

    }

    public void setElementText(WebElement element,String text){
        element.clear();
        element.sendKeys(text);
        Assert.assertEquals(element.getAttribute("value"),text);

    }

}
