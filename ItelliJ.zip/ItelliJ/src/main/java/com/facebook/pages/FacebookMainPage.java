package com.facebook.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by Arghya on 19-04-2016.
 */
public class FacebookMainPage extends BasePage{

    @FindBy(xpath=".//*[@id='email']")
    WebElement emailField;

    @FindBy(xpath=".//*[@id='pass2']")
    WebElement passwordField;

    public FacebookMainPage(WebDriver driver){
        super(driver);
    }

    public void setEmailText(String text){
        setElementText(emailField,text);
    }

    public void setPassword(String text){
        setElementText(passwordField,text);
    }
}
