package com.facebook.data;

import org.testng.annotations.DataProvider;

/**
 * Created by Arghya on 19-04-2016.
 */
public class FacebookData {


    @DataProvider(name="pages")
    public static Object[][] pages(){
        return new Object[][]{
                {"https://www.facebook.com","Facebook"}
        };
    }

    @DataProvider(name="pages2")
    public static Object[][] pages2(){
        return new Object[][]{
                {"https://www.facebook.com","Facebook"},
                {"https://www.google.com","Google"},
                {"https://www.yahoo.com","Yahoo"}
        };
    }

}
