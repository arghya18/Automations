package com.facebook.test;

import com.facebook.data.FacebookData;
import com.facebook.pages.FacebookMainPage;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.*;
import com.facebook.*;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.GregorianCalendar;

/**
 * Created by Arghya on 18-04-2016.
 */
public class LoginTest extends BaseTest{

    FacebookMainPage facebookMainPage;


    @Test(groups={"p1"},dataProvider = "pages",dataProviderClass = FacebookData.class)
    public void navigate(String url,String title) {
        facebookMainPage= PageFactory.initElements(driver,FacebookMainPage.class);
        driver.navigate().to(url);
        Assert.assertTrue(driver.getTitle().contains(title));

    }

    @Test(groups={"p1"} ,dependsOnMethods="navigate")
    public void enterUsername() {

        facebookMainPage.setEmailText("arghya4u");

    }

    @Test(groups={"p1"} ,dependsOnMethods="enterUsername")
    public void enterPassword() {

        facebookMainPage.setPassword("nikhilrs1");

    }

}
