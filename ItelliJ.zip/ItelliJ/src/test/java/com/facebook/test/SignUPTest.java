package com.facebook.test;

import com.facebook.data.FacebookData;
import com.facebook.pages.BasePage;
import com.facebook.pages.FacebookMainPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Created by Arghya on 24-04-2016.
 */
public class SignUPTest extends BaseTest{

    FacebookMainPage facebookMainPage;

    @Test(groups={"p1"},dataProvider = "pages",dataProviderClass = FacebookData.class)
    public void navigate(String url,String title) {
        facebookMainPage= PageFactory.initElements(driver,FacebookMainPage.class);
        driver.navigate().to(url);
        Assert.assertTrue(driver.getTitle().contains(title));

    }

    @Test(groups={"p1"} ,dependsOnMethods="navigate")
    public void enterUsername() {

        facebookMainPage.setEmailText("arghya4u");

    }

    @Test(groups={"p1"} ,dependsOnMethods="enterUsername")
    public void enterPassword() {

        facebookMainPage.setPassword("nikhilrs1");

    }

}
